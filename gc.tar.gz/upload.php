<?php
/**
 * upload.php
 * 简易示例，将前端传来的 file 保存至 ./wenjian/ 目录
 * 并返回 {status:'success', data: {file_name, file_url}, msg:''}
 */

// 设置返回JSON格式
header('Content-Type: application/json; charset=UTF-8');

// 确保有上传文件
if(!isset($_FILES['file'])){
    echo json_encode(['status'=>'fail','msg'=>'无文件上传','data'=>null]);
    exit;
}

$uploadDir = __DIR__ . '/wenjian/';
if(!is_dir($uploadDir)){
    // 若目录不存在，尝试创建(如不需要自动创建可去掉)
    mkdir($uploadDir, 0777, true);
}

// 简易生成新文件名(防止重名)
$originalName = $_FILES['file']['name'];
$ext = pathinfo($originalName, PATHINFO_EXTENSION);
$newName = time().'-'.mt_rand(1000,9999).".".$ext;

$targetPath = $uploadDir . $newName;
if(move_uploaded_file($_FILES['file']['tmp_name'], $targetPath)){
    // 成功
    // 构造可以访问的URL => 假设与 project.html 同目录下
    $fileUrl = 'wenjian/' . $newName;
    echo json_encode([
      'status'=>'success',
      'msg'=>'上传成功',
      'data'=>[
        'file_name' => $newName,
        'file_url'  => $fileUrl
      ]
    ]);
} else {
    // 失败
    echo json_encode([
      'status'=>'fail',
      'msg'=>'move_uploaded_file失败',
      'data'=>null
    ]);
}
