<?php
/**
 * save_data.php
 * 保存主索引数据
 */
header('Content-Type: application/json; charset=UTF-8');

$jsonString = file_get_contents("php://input");
if(!$jsonString){
    echo json_encode(["status"=>"fail","message"=>"无效的POST数据"]);
    exit;
}

$targetFile = 'categoriesData.json';  // 修正为当前目录

try {
    file_put_contents($targetFile, $jsonString);
    echo json_encode(["status"=>"ok","message"=>"数据已写入"]);
} catch(Exception $e){
    echo json_encode(["status"=>"fail","message"=>$e->getMessage()]);
}
