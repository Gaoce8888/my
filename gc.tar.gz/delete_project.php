<?php
/**
 * delete_project.php
 * 删除项目JSON文件
 */
header('Content-Type: application/json; charset=UTF-8');

$jsonString = file_get_contents("php://input");
if(!$jsonString){
    echo json_encode(["status"=>"fail","message"=>"无效的POST数据"]);
    exit;
}

try {
    // 解析请求数据
    $requestData = json_decode($jsonString, true);
    
    if(!isset($requestData['id'])) {
        echo json_encode(["status"=>"fail","message"=>"缺少项目ID参数"]);
        exit;
    }
    
    $projectId = $requestData['id'];
    // 安全检查：确保ID是数字
    if(!is_numeric($projectId)) {
        echo json_encode(["status"=>"fail","message"=>"无效的项目ID"]);
        exit;
    }
    
    $projectFileName = "project_{$projectId}.json";
    
    // 检查文件是否存在
    if(file_exists($projectFileName)) {
        // 尝试删除文件
        if(unlink($projectFileName)) {
            echo json_encode(["status"=>"ok","message"=>"项目文件已删除"]);
        } else {
            echo json_encode(["status"=>"fail","message"=>"无法删除项目文件"]);
        }
    } else {
        // 文件不存在也返回成功（因为目标是确保文件不存在）
        echo json_encode(["status"=>"ok","message"=>"项目文件不存在"]);
    }
} catch(Exception $e) {
    echo json_encode(["status"=>"fail","message"=>$e->getMessage()]);
}
