<?php
/**
 * save_project.php
 * 保存单个项目的JSON数据到独立文件
 */
header('Content-Type: application/json; charset=UTF-8');

$jsonString = file_get_contents("php://input");
if(!$jsonString){
    echo json_encode(["status"=>"fail","message"=>"无效的POST数据"]);
    exit;
}

try {
    // 解析请求数据
    $requestData = json_decode($jsonString, true);
    
    if(!isset($requestData['filename']) || !isset($requestData['data'])) {
        echo json_encode(["status"=>"fail","message"=>"缺少必要的参数"]);
        exit;
    }
    
    $filename = $requestData['filename'];
    
    // 验证文件名格式，只允许project_数字.json
    if(!preg_match('/^project_\d+\.json$/', $filename)) {
        echo json_encode(["status"=>"fail","message"=>"无效的项目文件名"]);
        exit;
    }
    
    // 将项目数据保存到文件
    $projectData = json_encode($requestData['data'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    file_put_contents($filename, $projectData);
    
    echo json_encode(["status"=>"ok","message"=>"项目数据已保存"]);
} catch(Exception $e) {
    echo json_encode(["status"=>"fail","message"=>$e->getMessage()]);
}
