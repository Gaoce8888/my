<?php
/**
 * setup.php
 * 系统初始化脚本
 */

// 确保上传目录存在
$uploadDir = __DIR__ . '/wenjian/';
if(!is_dir($uploadDir)){
    if(mkdir($uploadDir, 0777, true)){
        echo "创建上传目录成功: {$uploadDir}\n";
    } else {
        echo "创建上传目录失败\n";
    }
} else {
    echo "上传目录已存在\n";
}

// 创建示例项目数据
$exampleProject = [
    "id" => 1633938778000,
    "name" => "示例项目",
    "commands" => [
        [
            "cmd" => "echo 'Hello World'",
            "category" => "示例",
            "desc" => "一个简单的示例命令"
        ]
    ],
    "links" => [
        [
            "url" => "https://www.example.com",
            "name" => "示例链接"
        ]
    ],
    "memos" => [],
    "files" => [],
    "pages" => []
];

// 创建主索引文件
$indexData = [
    [
        "id" => 1633938778000,
        "name" => "示例项目"
    ]
];

// 写入项目数据
$projectFile = 'project_1633938778000.json';
if(!file_exists($projectFile)){
    if(file_put_contents($projectFile, json_encode($exampleProject, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))){
        echo "创建示例项目成功\n";
    } else {
        echo "创建示例项目失败\n";
    }
} else {
    echo "示例项目文件已存在\n";
}

// 写入索引数据
$indexFile = 'categoriesData.json';
if(!file_exists($indexFile)){
    if(file_put_contents($indexFile, json_encode($indexData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))){
        echo "创建索引文件成功\n";
    } else {
        echo "创建索引文件失败\n";
    }
} else {
    echo "索引文件已存在\n";
}

// 检查必要的PHP文件是否存在
$requiredFiles = ['save_data.php', 'save_project.php', 'delete_project.php', 'upload.php'];
foreach($requiredFiles as $file){
    if(file_exists($file)){
        echo "{$file} 文件已存在\n";
    } else {
        echo "{$file} 文件不存在，请创建\n";
    }
}

echo "\n初始化完成，请通过浏览器访问index.html开始使用！\n";
